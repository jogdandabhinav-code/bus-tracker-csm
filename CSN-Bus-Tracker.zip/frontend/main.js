const map = L.map('map').setView([19.8512,75.7147],13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
let markers = [];
const busSelect = document.getElementById('busSelect');
const timetableDiv = document.getElementById('timetable');
fetch('http://localhost:3000/api/buses')
.then(res => res.json())
.then(data => {
    data.forEach(bus => {
        const option = document.createElement('option');
        option.value = bus.number;
        option.textContent = bus.number;
        busSelect.appendChild(option);
    });
});
busSelect.addEventListener('change', ()=>{
    const busNumber = busSelect.value;
    if(!busNumber) return;
    fetch(`http://localhost:3000/api/bus/${busNumber}`)
    .then(res=>res.json())
    .then(data=>{
        markers.forEach(m=>map.removeLayer(m));
        markers = [];
        data.bus.route.forEach((stop,i)=>{
            const marker = L.marker([data.bus.location.lat + i*0.0005, data.bus.location.lng + i*0.0005])
            .addTo(map)
            .bindPopup(`Bus ${busNumber}: ${stop} - ${data.bus.location.status}`);
            markers.push(marker);
        });
        if(markers.length) map.setView([markers[0]._latlng.lat, markers[0]._latlng.lng],14);
        timetableDiv.innerHTML = `<h3>Timetable for Bus ${busNumber}</h3><ul>${data.timetable.map(t=>`<li>${t}</li>`).join('')}</ul>`;
    });
});