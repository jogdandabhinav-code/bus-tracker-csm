const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(express.json());
const buses = JSON.parse(fs.readFileSync('./data/buses.json'));
const timetable = JSON.parse(fs.readFileSync('./data/timetable.json'));
app.get('/api/buses', (req, res) => { res.json(buses); });
app.get('/api/bus/:busNumber', (req, res) => {
    const busNumber = req.params.busNumber;
    const bus = buses.find(b => b.number === busNumber);
    const busTime = timetable[busNumber] || [];
    if(bus){ res.json({bus, timetable: busTime}); } else { res.status(404).json({error: 'Bus not found'}); }
});
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));